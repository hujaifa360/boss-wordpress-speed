# HTML to WordPress Theme Demo

This project shows how a static HTML template is converted into a dynamic WordPress theme.

## Features

- Split HTML into `header.php`, `footer.php`, and `index.php`
- Added dynamic WordPress tags
- Enqueued styles via `functions.php`

Use this to showcase basic theme development skills for freelancing.
