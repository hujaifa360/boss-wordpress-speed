<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php bloginfo('name'); ?> | <?php wp_title(); ?></title>
    <?php wp_head(); ?>
</head>
<body>
<header>
    <h1>Welcome to <?php bloginfo('name'); ?></h1>
    <nav>
        <a href="#">Home</a>
        <a href="#">About</a>
    </nav>
</header>
