<?php get_header(); ?>
<main>
    <p>This is a sample WordPress theme converted from HTML.</p>
</main>
<?php get_footer(); ?>
